# MIT License
#
# Copyright (c) 2023 AnonymousX1025
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

from FallenMusic import BOT_NAME

PM_START_TEXT = """
𝐇𝐄𝐘 {𝟎}🥀
๏ 𝐓𝐇𝐈𝐒 𝐈𝐒** {𝟏} !  
➻ 𝐀 𝐅𝐀𝐒𝐓 𝐀𝐍𝐃 𝐏𝐎𝐖𝐄𝐑𝐅𝐔𝐋 𝐌𝐔𝐒𝐈𝐂 𝐏𝐋𝐀𝐘𝐄𝐑 𝐁𝐎𝐓. """

START_TEXT = """
**𝐇𝐄𝐘** {0}, 🥀
  {1} 𝐂𝐀𝐍 𝐍𝐎𝐖 𝐏𝐋𝐀𝐘 𝐒𝐎𝐍𝐆𝐒 𝐈𝐍 {2}
──────────────────
➻ 𝐅𝐎𝐑 𝐆𝐄𝐓𝐓𝐈𝐍𝐆 𝐇𝐄𝐋𝐏 𝐀𝐁𝐎𝐔𝐓 𝐌𝐄 𝐎𝐑 𝐈𝐅 𝐘𝐎𝐔 𝐖𝐀𝐍𝐍𝐀 𝐀𝐒𝐊 𝐒𝐎𝐌𝐄𝐓𝐇𝐈𝐍𝐆 𝐘𝐎𝐔 𝐂𝐒𝐍 𝐉𝐎𝐈𝐍 𝐌𝐘 
 [sᴜᴘᴘᴏʀᴛ ᴄʜᴀᴛ]({3}).
"""


HELP_TEXT = f"""
<u>❄ **𝐀𝐕𝐀𝐈𝐋𝐀𝐁𝐋𝐄 𝐂𝐎𝐌𝐌𝐀𝐍𝐃𝐒 𝐅𝐎𝐑 𝐔𝐒𝐄𝐑𝐒 𝐈𝐍
 {BOT_NAME} :**</u>

๏ /play : 𝐒𝐓𝐀𝐑𝐓𝐒 𝐒𝐓𝐑𝐄𝐀𝐌𝐈𝐍𝐆 𝐓𝐇𝐄 𝐑𝐄𝐐𝐔𝐄𝐒𝐓𝐒 𝐓𝐑𝐀𝐊 𝐎𝐍 𝐕𝐈𝐃𝐄𝐎𝐂𝐇𝐀𝐓.
๏ /pause : 𝐏𝐀𝐔𝐒𝐄 𝐓𝐇𝐄 𝐂𝐔𝐑𝐑𝐄𝐍𝐓 𝐏𝐋𝐀𝐘𝐈𝐍𝐆 𝐒𝐓𝐑𝐄𝐀𝐌.
๏ /resume : 𝐑𝐄𝐒𝐔𝐌𝐄 𝐓𝐇𝐄 𝐏𝐀𝐔𝐒𝐄𝐃 𝐒𝐓𝐑𝐄𝐀𝐌.
๏ /skip : 𝐒𝐊𝐈𝐏 𝐓𝐇𝐄 𝐂𝐔𝐑𝐑𝐄𝐍𝐓 𝐏𝐋𝐀𝐘𝐈𝐍𝐆 𝐒𝐓𝐑𝐄𝐀𝐌 𝐀𝐍𝐃 𝐒𝐓𝐀𝐑𝐓 𝐒𝐓𝐑𝐄𝐀𝐌𝐈𝐍𝐆 𝐓𝐇𝐄 𝐍𝐄𝐗𝐓 𝐓𝐑𝐀𝐂𝐊 𝐈𝐍 𝐐𝐔𝐄𝐔𝐄.
๏ /end : 𝐂𝐋𝐄𝐀𝐑𝐒 𝐓𝐇𝐄 𝐐𝐔𝐄𝐔𝐄 𝐀𝐍𝐃 𝐄𝐍𝐃 𝐓𝐇𝐄 𝐂𝐔𝐑𝐑𝐄𝐍𝐓 𝐏𝐋𝐀𝐘𝐈𝐍𝐆 𝐒𝐓𝐑𝐄𝐀𝐌.
 
๏ /ping : 𝐒𝐇𝐎𝐖 𝐓𝐇𝐄 𝐏𝐈𝐍𝐆 𝐀𝐍𝐃 𝐒𝐘𝐒𝐓𝐄𝐌 𝐒𝐓𝐀𝐓𝐒 𝐎𝐅 𝐓𝐇𝐄 𝐁𝐎𝐓.
๏ /sudolist : 𝐒𝐇𝐎𝐖𝐒 𝐓𝐇𝐄 𝐋𝐈𝐒𝐓 𝐎𝐅 𝐒𝐔𝐃𝐎 𝐔𝐒𝐄𝐑𝐒 𝐎𝐅 𝐓𝐇𝐄 𝐁𝐎𝐓.

๏ /song : 𝐃𝐎𝐖𝐍𝐋𝐎𝐀𝐃𝐒 𝐓𝐇𝐄 𝐑𝐄𝐐𝐔𝐄𝐒𝐓𝐄𝐃 𝐒𝐎𝐍𝐆 𝐀𝐍𝐃 𝐒𝐄𝐍𝐃 𝐈𝐓 𝐓𝐎 𝐘𝐎𝐔.

๏ /search : 𝐒𝐄𝐀𝐑𝐂𝐇 𝐓𝐇𝐄 𝐆𝐈𝐕𝐄𝐍 𝐐𝐔𝐄𝐑𝐘 𝐎𝐍 𝐘𝐎𝐔𝐓𝐔𝐁𝐄 𝐀𝐍𝐃 𝐒𝐇𝐎𝐖𝐒 𝐘𝐎𝐔 𝐓𝐇𝐄 𝐑𝐄𝐒𝐔𝐋𝐓.
"""

HELP_SUDO = f"""
<u>✨ **𝐒𝐔𝐃𝐎 𝐂𝐎𝐌𝐌𝐀𝐍𝐃𝐒 𝐈𝐍 {BOT_NAME} :**</u>

๏ /activevc : 𝐒𝐇𝐎𝐖𝐒 𝐓𝐇𝐄 𝐋𝐈𝐒𝐓 𝐎𝐅 𝐂𝐔𝐑𝐑𝐄𝐍𝐓𝐋𝐘 𝐀𝐂𝐓𝐈𝐕𝐄 𝐕𝐎𝐈𝐂𝐄𝐂𝐇𝐀𝐓𝐒.
๏ /eval or /sh : 𝐑𝐔𝐍𝐒 𝐓𝐇𝐄 𝐆𝐈𝐕𝐄𝐍 𝐂𝐎𝐃𝐄 𝐎𝐍 𝐓𝐇𝐄 𝐁𝐎𝐓'𝐒 𝐓𝐄𝐑𝐌𝐈𝐍𝐀𝐋.
๏ /speedtest : 𝐑𝐔𝐍𝐒 𝐀 𝐒𝐏𝐄𝐄𝐃𝐓𝐄𝐒𝐓 𝐎𝐍 𝐓𝐇𝐄 𝐁𝐎𝐓'𝐒 𝐒𝐄𝐑𝐕𝐄𝐑.
๏ /sysstats : 𝐒𝐇𝐎𝐖𝐒 𝐓𝐇𝐄 𝐒𝐘𝐒𝐓𝐄𝐌 𝐒𝐓𝐀𝐓𝐒 𝐎𝐅 𝐓𝐇𝐄 𝐁𝐎𝐓'𝐒 𝐒𝐄𝐑𝐕𝐄𝐑.

๏ /setname [ᴛᴇxᴛ ᴏʀ ʀᴇᴘʟʏ ᴛᴏ ᴀ ᴛᴇxᴛ] : 𝐂𝐇𝐀𝐑𝐆𝐄 𝐓𝐇𝐄 𝐀𝐒𝐒𝐈𝐒𝐓𝐀𝐍𝐓 𝐀𝐂𝐂𝐎𝐔𝐍𝐓 𝐍𝐀𝐌𝐄.
๏ /setbio [ᴛᴇxᴛ ᴏʀ ʀᴇᴘʟʏ ᴛᴏ ᴀ ᴛᴇxᴛ] : 𝐂𝐇𝐀𝐑𝐆𝐄 𝐓𝐇𝐄 𝐁𝐈𝐎 𝐎𝐅 𝐀𝐒𝐒𝐈𝐒𝐓𝐀𝐍𝐓 𝐀𝐂𝐂𝐎𝐔𝐍𝐓 𝐍𝐀𝐌𝐄.
๏ /setpfp [ʀᴇᴘʟʏ ᴛᴏ ᴀ ᴘʜᴏᴛᴏ] : CHARGE THE 𝐏𝐅𝐏 𝐎𝐅 ASSISTANT ACCOUNT NAME.
๏ /delpfp : 𝐃𝐄𝐋𝐄𝐓𝐄 𝐓𝐇𝐄 𝐂𝐔𝐑𝐑𝐄𝐍𝐓 𝐏𝐅𝐏 𝐎𝐅 𝐀𝐒𝐒𝐈𝐒𝐓𝐀𝐍𝐓 𝐀𝐂𝐂𝐎𝐔𝐍𝐓 𝐍𝐀𝐌𝐄.
"""

HELP_DEV = f"""
<u>✨ **𝐎𝐖𝐍𝐄𝐑 𝐂𝐎𝐌𝐌𝐀𝐍𝐃 IN {BOT_NAME} :**</u>

๏ /config : 𝐓𝐎 𝐆𝐄𝐓 𝐀𝐋𝐋 𝐂𝐎𝐍𝐅𝐈𝐂 𝐕𝐀𝐑𝐈𝐁𝐋𝐄𝐒 𝐎𝐅 𝐁𝐎𝐓.
๏ /broadcast [𝐌𝐄𝐒𝐒𝐀𝐆𝐄 𝐎𝐑 𝐑𝐄𝐏𝐋𝐘 𝐓𝐎 𝐀 𝐑𝐄𝐏𝐋𝐘] : 𝐁𝐑𝐎𝐀𝐃𝐂𝐀𝐒𝐓 𝐓𝐇𝐄 𝐌𝐄𝐒𝐒𝐀𝐆𝐄 𝐓𝐎 𝐒𝐄𝐑𝐕𝐄𝐃 𝐂𝐇𝐀𝐓𝐒 𝐎𝐅 𝐓𝐇𝐄 𝐁𝐎𝐓.
๏ /rmdownloads : 𝐂𝐋𝐄𝐀𝐑𝐒 𝐓𝐇𝐄 𝐂𝐇𝐀𝐂𝐇𝐄 𝐅𝐈𝐋𝐄𝐒 𝐃𝐎𝐖𝐍𝐋𝐎𝐀𝐃 𝐎𝐍 𝐓𝐇𝐄 𝐁𝐎𝐓'𝐒 𝐒𝐄𝐑𝐕𝐄𝐑.
๏ /leaveall : 𝐎𝐑𝐃𝐄𝐑𝐒 𝐓𝐇𝐄 𝐀𝐒𝐒𝐈𝐒𝐓𝐀𝐍𝐓 𝐀𝐂𝐂𝐎𝐔𝐍𝐓 𝐓𝐎 𝐋𝐄𝐀𝐕𝐄 𝐀𝐋𝐋 𝐂𝐇𝐀𝐓𝐒.

๏ /addsudo [𝐌𝐄𝐒𝐒𝐀𝐆𝐄 𝐎𝐑 𝐑𝐄𝐏𝐋𝐘 𝐓𝐎 𝐀 𝐑𝐄𝐏𝐋𝐘] : 𝐀𝐃𝐃 𝐓𝐇𝐄 𝐔𝐒𝐄𝐑 𝐓𝐎 𝐀 𝐒𝐔𝐃𝐎 𝐔𝐒𝐄𝐑 𝐋𝐈𝐒𝐓.
๏ /rmsudo [𝐌𝐄𝐒𝐒𝐀𝐆𝐄 𝐎𝐑 𝐑𝐄𝐏𝐋𝐘 𝐓𝐎 𝐀 𝐑𝐄𝐏𝐋𝐘] : 𝐑𝐄𝐌𝐎𝐕𝐄 𝐓𝐇𝐄 𝐔𝐒𝐄𝐑 𝐅𝐑𝐎𝐌 𝐒𝐔𝐃𝐎 𝐔𝐒𝐄𝐑𝐒 𝐋𝐈𝐒𝐓. 
"""